// ══════════════════════════════════════════════════════════════
// Netlify Function: POST /api/otp/verify
// Verifies SMS OTP through Authentica.sa with advanced security.
// Features: Brute force protection, rate limiting, input validation.
// ══════════════════════════════════════════════════════════════

const AUTHENTICA = "https://api.authentica.sa";
const CRED = process.env.AUTHENTICA_API_SECRET || process.env.AUTHENTICA_API_KEY || "";

// ── Rate limiting ────────────────────────────────────────────
const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW = 60000;
const RATE_LIMIT_MAX = 10; // 10 requests per minute per IP
const RATE_LIMIT_VERIFY_MAX = 5; // 5 verification attempts per phone per minute

// ── Brute force tracking ─────────────────────────────────────
const failedAttempts = new Map();
const BRUTE_FORCE_WINDOW = 900000; // 15 minutes
const BRUTE_FORCE_MAX = 10; // 10 failed attempts = block

setInterval(() => {
  const now = Date.now();
  for (const [key, data] of rateLimitMap) {
    if (now - data.first > RATE_LIMIT_WINDOW) rateLimitMap.delete(key);
  }
  for (const [key, data] of failedAttempts) {
    if (now - data.first > BRUTE_FORCE_WINDOW) failedAttempts.delete(key);
  }
}, 60000);

function checkRateLimit(key, max) {
  const now = Date.now();
  const entry = rateLimitMap.get(key);
  if (!entry || now - entry.first > RATE_LIMIT_WINDOW) {
    rateLimitMap.set(key, { first: now, count: 1 });
    return true;
  }
  if (entry.count >= max) return false;
  entry.count++;
  return true;
}

function checkBruteForce(key) {
  const now = Date.now();
  const entry = failedAttempts.get(key);
  if (!entry || now - entry.first > BRUTE_FORCE_WINDOW) {
    failedAttempts.set(key, { first: now, count: 1 });
    return true;
  }
  if (entry.count >= BRUTE_FORCE_MAX) return false;
  entry.count++;
  return true;
}

function recordFailure(key) {
  const now = Date.now();
  const entry = failedAttempts.get(key);
  if (!entry || now - entry.first > BRUTE_FORCE_WINDOW) {
    failedAttempts.set(key, { first: now, count: 1 });
  } else {
    entry.count++;
  }
}

function clearFailures(key) {
  failedAttempts.delete(key);
}

// ── Input sanitization ───────────────────────────────────────
function sanitizeInput(input) {
  return String(input || "").replace(/[<>"'`;\\]/g, "").trim().slice(0, 20);
}

function normalizePhone(raw) {
  const d = String(raw || "").replace(/\D/g, "");
  if (d.startsWith("966")) return "+" + d;
  if (d.startsWith("05")) return "+966" + d.slice(1);
  if (d.startsWith("5") && d.length === 9) return "+966" + d;
  return "+" + d;
}

function isValidSaudi(raw) {
  const d = String(raw || "").replace(/\D/g, "");
  return /^(05\d{8}|9665\d{8}|5\d{8})$/.test(d);
}

const securityHeaders = {
  "Content-Type": "application/json; charset=utf-8",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Cache-Control": "no-store, no-cache, must-revalidate",
  "Pragma": "no-cache",
  "Access-Control-Allow-Origin": "https://deltastars.store",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const json = (status, obj) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: securityHeaders,
  });

export default async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: securityHeaders });
  }

  if (req.method !== "POST") return json(405, { success: false, error: "Method not allowed" });

  // ── Rate limiting ──
  const clientIP = req.headers.get("x-forwarded-for")?.split(",")[0] || "unknown";
  if (!checkRateLimit(`ip:${clientIP}`, RATE_LIMIT_MAX)) {
    return json(429, { success: false, error: "تم تجاوز الحد المسموح. يرجى المحاولة بعد دقيقة." });
  }

  // ── Parse body ──
  let body = {};
  try { body = await req.json(); } catch {
    return json(400, { success: false, error: "بيانات غير صالحة" });
  }

  const phone = sanitizeInput(body.phone);
  const code = body.code != null ? String(body.code).replace(/\D/g, "") : "";
  if (!phone || !code) return json(400, { success: false, error: "رقم الجوال والرمز مطلوبان" });
  if (!isValidSaudi(phone)) return json(400, { success: false, error: "رقم الجوال غير صحيح" });
  if (!/^\d{4,6}$/.test(code)) return json(400, { success: false, error: "رمز التحقق يجب أن يكون 4-6 أرقام" });

  if (!CRED) return json(500, { success: false, error: "خدمة الرسائل غير مهيأة على الخادم (AUTHENTICA_API_SECRET مفقود)" });

  const normalized = normalizePhone(phone);

  // ── Brute force protection ──
  if (!checkBruteForce(`verify:${normalized}`)) {
    return json(429, { success: false, error: "تم حظر المحاولات مؤقتاً بسبب محاولات كثيرة خاطئة. حاول بعد 15 دقيقة." });
  }

  // ── Rate limit per phone ──
  if (!checkRateLimit(`verify:${normalized}`, RATE_LIMIT_VERIFY_MAX)) {
    return json(429, { success: false, error: "تم تجاوز الحد المسموح对此 الرقم. يرجى المحاولة بعد دقيقة." });
  }

  try {
    const r = await fetch(`${AUTHENTICA}/api/v1/verify-otp`, {
      method: "POST",
      headers: {
        "X-Authorization": CRED,
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify({ phone: normalized, otp: code }),
    });
    const data = await r.json().catch(() => ({}));
    const verified =
      r.ok && data.status !== false && data.success !== false && data.verified !== false;

    if (!verified) {
      recordFailure(`verify:${normalized}`);
      if (!r.ok && r.status !== 422) {
        return json(502, { success: false, error: "تعذّر التحقق من الرمز حالياً. حاول مجدداً." });
      }
      return json(422, { success: false, error: data.message || "رمز التحقق غير صحيح أو منتهي الصلاحية" });
    }

    clearFailures(`verify:${normalized}`);
    return json(200, {
      success: true,
      verified: true,
      phone: normalized,
      user: { phone: normalized, role: "customer", verified: true },
    });
  } catch {
    return json(500, { success: false, error: "تعذّر الاتصال بخدمة التحقق" });
  }
};
