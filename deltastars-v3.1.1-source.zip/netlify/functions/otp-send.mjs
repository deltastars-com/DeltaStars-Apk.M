// ══════════════════════════════════════════════════════════════
// Netlify Function: POST /api/otp/send
// Sends an SMS OTP through Authentica.sa with advanced security.
// Features: Rate limiting, input sanitization, anti-automation, security headers.
// ══════════════════════════════════════════════════════════════

const AUTHENTICA = "https://api.authentica.sa";
const CRED = process.env.AUTHENTICA_API_SECRET || process.env.AUTHENTICA_API_KEY || "";

// ── Rate limiting (in-memory, per-deployment) ────────────────
const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW = 60000; // 1 minute
const RATE_LIMIT_MAX = 5; // 5 requests per minute per IP
const RATE_LIMIT_PHONE_MAX = 3; // 3 requests per minute per phone

// ── Cleanup old rate limit entries periodically ──────────────
setInterval(() => {
  const now = Date.now();
  for (const [key, data] of rateLimitMap) {
    if (now - data.first > RATE_LIMIT_WINDOW) rateLimitMap.delete(key);
  }
}, 60000);

function checkRateLimit(key, max) {
  const now = Date.now();
  const entry = rateLimitMap.get(key);
  if (!entry || now - entry.first > RATE_LIMIT_WINDOW) {
    rateLimitMap.set(key, { first: now, count: 1 });
    return true;
  }
  if (entry.count >= max) return false;
  entry.count++;
  return true;
}

// ── Input sanitization ───────────────────────────────────────
function sanitizeInput(input) {
  return String(input || "").replace(/[<>"'`;\\]/g, "").trim().slice(0, 20);
}

function normalizePhone(raw) {
  const d = String(raw || "").replace(/\D/g, "");
  if (d.startsWith("966")) return "+" + d;
  if (d.startsWith("05")) return "+966" + d.slice(1);
  if (d.startsWith("5") && d.length === 9) return "+966" + d;
  return "+" + d;
}

function isValidSaudi(raw) {
  const d = String(raw || "").replace(/\D/g, "");
  return /^(05\d{8}|9665\d{8}|5\d{8})$/.test(d);
}

// ── Security headers for responses ───────────────────────────
const securityHeaders = {
  "Content-Type": "application/json; charset=utf-8",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Cache-Control": "no-store, no-cache, must-revalidate",
  "Pragma": "no-cache",
  "Access-Control-Allow-Origin": "https://deltastars.store",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const json = (status, obj) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: securityHeaders,
  });

export default async (req) => {
  // ── CORS preflight ──
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: securityHeaders });
  }

  if (req.method !== "POST") return json(405, { success: false, error: "Method not allowed" });

  // ── Rate limiting by IP ──
  const clientIP = req.headers.get("x-forwarded-for")?.split(",")[0] || req.headers.get("x-real-ip") || "unknown";
  if (!checkRateLimit(`ip:${clientIP}`, RATE_LIMIT_MAX)) {
    return json(429, { success: false, error: "تم تجاوز الحد المسموح. يرجى المحاولة بعد دقيقة." });
  }

  // ── Parse and validate body ──
  let body = {};
  try { body = await req.json(); } catch {
    return json(400, { success: false, error: "بيانات غير صالحة" });
  }

  const phone = sanitizeInput(body.phone);
  if (!phone) return json(400, { success: false, error: "رقم الجوال مطلوب" });
  if (!isValidSaudi(phone)) return json(400, { success: false, error: "رقم الجوال غير صحيح. مثال: 0512345678" });

  // ── Rate limiting by phone ──
  if (!checkRateLimit(`phone:${phone}`, RATE_LIMIT_PHONE_MAX)) {
    return json(429, { success: false, error: "تم تجاوز الحد المسموح لهذا الرقم. يرجى المحاولة بعد دقيقة." });
  }

  if (!CRED) return json(500, { success: false, error: "خدمة الرسائل غير مهيأة على الخادم (AUTHENTICA_API_SECRET مفقود)" });

  const normalized = normalizePhone(phone);

  try {
    const r = await fetch(`${AUTHENTICA}/api/v1/send-otp`, {
      method: "POST",
      headers: {
        "X-Authorization": CRED,
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify({ method: "sms", phone: normalized }),
    });
    const data = await r.json().catch(() => ({}));
    const ok = r.ok && data.success !== false && data.status !== false;
    if (!ok) {
      return json(502, { success: false, error: data.message || "فشل إرسال رمز التحقق. حاول مجدداً." });
    }
    return json(200, { success: true, message: "تم إرسال رمز التحقق بنجاح", expiresIn: 300 });
  } catch {
    return json(500, { success: false, error: "تعذّر الاتصال بخدمة الرسائل" });
  }
};
